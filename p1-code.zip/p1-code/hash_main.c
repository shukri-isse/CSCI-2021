#include <stdio.h>
#include <string.h>
#include "hashmap.h"

int main(int argc, char *argv[]){
    int echo = 0;
    if(argc > 1 && strcmp("-echo",argv[1])==0) {
        echo=1;
    }

    printf("Hashmap Main\n");
    printf("Commands:\n");
    printf("  hashcode <key>   : prints out the numeric hash code for the given key (does not change the hash map)\n");
    printf("  put <key> <val>  : inserts the given key/val into the hash map, overwrites existing values if present\n");
    printf("  get <key>        : prints the value associated with the given key or NOT FOUND\n");
    printf("  print            : shows contents of the hashmap ordered by how they appear in the table\n");
    printf("  structure        : prints detailed structure of the hash map\n");
    printf("  clear            : reinitializes hash map to be empty with default size\n");
    printf("  save <file>      : writes the contents of the hash map the given file\n");
    printf("  load <file>      : clears the current hash map and loads the one in the given file\n");
    printf("  next_prime <int> : if <int> is prime, prints it, otherwise finds the next prime and prints it\n");
    printf("  expand           : expands memory size of hashmap to reduce its load factor\n");
    printf("  quit             : exit the program\n");

    char cmd[128];
    hashmap_t hm;
    hashnode_t *current = hm->table;
    int success;
    hashmap_init(&hm);

    while(1){
        printf("HM> ");
        success = fscanf(stdin,"%s",cmd);
        if(success == EOF){
            printf("\n");
            break;
        }
        if( strcmp("hashcode", cmd)==0 ){
            if(echo){
                printf("hashcode %s\n", current->key);
            }
            break;  
        }
        else if( strcmp("put", cmd)==0 ){
            if(echo){
                printf("put %s %s\n", current->key, current->val);
            }
            break;  
        }
        else if( strcmp("get", cmd)==0 ){
            if(echo){
                printf("get %s\n", current->key);
            }
            break;  
        }
        else if( strcmp("print", cmd)==0 ){
            if(echo){
                printf("print\n");
            }
            break;  
        }
        else if( strcmp("structure", cmd)==0 ){
            if(echo){
                printf("structure\n");
            }
            break;  
        }
        else if( strcmp("clear", cmd)==0 ){
            if(echo){
                printf("clear\n");
            }
            break;  
        }
        else if( strcmp("save", cmd)==0 ){
            if(echo){
                printf("save\n");
            }
            break;  
        }
        else if( strcmp("load", cmd)==0 ){
            if(echo){
                printf("load\n");
            }
            break;  
        }
        else if( strcmp("next_prime", cmd)==0 ){
            if(echo){
                printf("next_prime\n");
            }
            break;  
        }
        else if( strcmp("expand", cmd)==0 ){
            if(echo){
                printf("expand\n");
            }
            break;  
        }
        else if( strcmp("quit", cmd)==0 ){
            if(echo){
                printf("quit\n");
            }
            break;  
        }
        else{
            if(echo){
                printf("%s\n", cmd);
            }
            printf("unknown command %s\n", cmd);
        }
    }
}