#include "thermo.h"

// int set_temp_from_ports(temp_t *temp){
//     if(THERMO_SENSOR_PORT < 0 || THERMO_SENSOR_PORT > 28800 || THERMO_STATUS_PORT & (1<<2)){ //check for error if THERMO_SENSOR_PORT is below min or above max
//         temp -> tenths_degrees = 0;
//         temp -> temp_mode = 3;
//         return 1; //returns 1 for error
//     }
//     else{ 
//     int Celsius = (THERMO_SENSOR_PORT >> 5) - 450; //divides by 32 and subtracts 45.0
//     int remainder = THERMO_SENSOR_PORT & 0b11111;
//         if(remainder >=16){
//             Celsius += 1;
//         }
//         if(THERMO_STATUS_PORT & (1<<5)){ //Further converts to deg F if indicated from THERMO_STATUS_PORT if  bit 5 is 1
//             int Fahrenheit = Celsius * 90 / 50 + 320;
//             temp->tenths_degrees = Fahrenheit;
//             temp-> temp_mode = 2; //sets temp_mode to 2 since we converted to farenheit
//         }
//         else { 
//             temp->tenths_degrees = Celsius;
//             temp->temp_mode = 1; //else sets temp_mode to 1 since we are using celsius
//         }
//         return 0; //returns 0 for success
//         }
// }

int set_display_from_temp(temp_t temp, int *display){
int bitmask = 0; //creates a local int initialized to 0, arranging the display, and then deref-setting display to that integer  
int bitMaskArr[13] = { 0b1111011, 0b1001000, 0b0111101, 0b1101101, 0b1001110, 0b1100111, 0b1110111, 0b1001001, 0b1111111, 0b1101111, 0b0000100, 0b0110111, 0b1011111}; //Creates an array of bit masks for each of the digits 0-9, minus, E, R
int mod_result; //Use modulo to determine the integer value for the tens, ones, and tenths digits for the temperature. Call these variables something like temp_hundreds, temp_tens and so on. Each variable should be in the range 0-9
int neg = 0; //initializes int neg which will later be used to identify when we have a neg temperature
if (temp.tenths_degrees<0) {mod_result = temp.tenths_degrees*-1;
neg =1;}
else {mod_result = temp.tenths_degrees;}
int temp_tenths = mod_result % 10;
mod_result = mod_result / 10;
int temp_ones = mod_result % 10;
mod_result = mod_result/10;
int temp_tens = mod_result % 10;
mod_result = mod_result/10;
int temp_hundreds = mod_result % 10;
if((temp.temp_mode == 1 && (temp.tenths_degrees < -450 || temp.tenths_degrees > 450)) || (temp.temp_mode == 2 && (temp.tenths_degrees < -490 || temp.tenths_degrees > 1130)) || (temp.temp_mode != 1 && temp.temp_mode !=2) ){ 
    bitmask = bitmask | (bitMaskArr[11]<<21);
    bitmask = bitmask | (bitMaskArr[12]<<14);
    bitmask = bitmask | (bitMaskArr[12]<<7);
    *display = bitmask;
    return 1; //after the error message is printed function should be exited
    }
if(temp.temp_mode == 2){//Fahrenheit
    bitmask = bitmask | (1 << 29);
}
else{//Celsius (temp.temp_mode should equal 1)
    bitmask = bitmask | (1<< 28);
}
if(temp_hundreds != 0){ //shifts the hundreds value into the hundreds place
    bitmask = bitmask | (bitMaskArr[temp_hundreds]<<21);
}
if(temp_hundreds !=0 || temp_tens != 0){ //shifts tens value into the tens place
    bitmask = bitmask | (bitMaskArr[temp_tens]<<14); 
}
if(neg ==1 && temp_hundreds == 0 && temp_tens == 0){ //shifts the minus into the tens place if our temperature is neg and hundreds and tens place have 0's
    bitmask = bitmask | (bitMaskArr[10]<<14);
}
else if(temp_hundreds == 0 && temp_tens !=0 && neg == 1){ //shifts the minus into the thundreds place if our temperature is neg and hundreds place has 0's and tens place is not 0
    bitmask = bitmask | (bitMaskArr[10]<<21);
}
bitmask = bitmask | ( bitMaskArr[temp_ones] << 7); //shifts the ones value into the ones place
bitmask = bitmask | bitMaskArr[temp_tenths]; //shifts the tenths value into the tenths place
*display = bitmask;
return 0; //returns 0 if successfully displayed
}

int thermo_update(){
// Called to update the thermometer display.  Makes use of
// set_temp_from_ports() and set_display_from_temp() to access
// temperature sensor then set the display. Always sets the display
// even if the other functions returns an error. Returns 0 if both
// functions complete successfully and return 0. Returns 1 if either
// function or both return a non-zero values.
// 
// CONSTRAINT: Does not allocate any heap memory as malloc() is NOT
// available on the target microcontroller.  Uses stack and global
// memory only.
temp_t temp = {};
int results_set_temp_from_ports = set_temp_from_ports( &temp);
int disp = 0;
int results_set_display_from_temp = set_display_from_temp( temp, &disp);
THERMO_DISPLAY_PORT = disp;
int ret = results_set_temp_from_ports || results_set_display_from_temp;
return ret;
}
