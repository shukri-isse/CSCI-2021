// Complete this main to benchmark the search algorithms outlined in
// the project specification
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <error.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "search.h"

double total_points = 0;
double actual_score = 0;

#include "data.c"

int main(int argc, char *argv[]){
  // if arvc < 4 then print out the usage ...
  //usage: ./search_benchmark <minpow> <maxpow> <repeats> [alg1 alg2 ...]
    //  with alg1 alg2 as a combination of:
    //   la : Linear Array Search
    //   ll : Linked List Search
    //   ba : Binary Array Search
    //   bt : Binary Tree Search
    //   (default all)
  if(argc < 4){
    char *usage = "usage: ./search_benchmark, <minpow> <maxpow> <repeats> [alg1 alg2 ... *format, ...";
    char *str1 = "with alg1 alg2 as a combination of:";
    char *str2 = "la : Linear Array Search"; //char str3[] will point to first character in string not entire string
    char *str3 = "ll : Linked List Search";
    char *str4 = "ba : Binary Array Search";
    char *str5 = "bt : Binary Tree Search";
    char *str6 = "(default all)";
    printf("%s %s\n %s\n %s\n %s\n %s\n %s\n", usage, str1, str2, str3, str4, str5, str6);
    return 1;
  }
  // code ...
  // return the program with 1

  int min_pow = atoi(argv[1]);  //// atoi = ASCII TO Int
  //int min_length = 1 << min_pow; //specify a minimum and maximum size of the search data structures
  int max_pow = atoi(argv[2]);
  //int max_length = 1 << max_pow;
  int repetitions = atoi(argv[3]);

  int run_linear_array = 1;
  int run_linear_list = 1;
  int run_binary_array = 1;
  int run_binary_tree = 1;

  if(argc > 4){ 
    //turn off all algorithms since command line arguments dictate which to run
      run_linear_array = 0;
      run_linear_list = 0;
      run_binary_array = 0;
      run_binary_tree = 0;
      // loop that starts from i = 4 until ..argc
      for(int i = 4; i<argc; i++){
        if(strcmp (argv[i], "la") == 0){
           run_linear_array = 1;
           //printf("%13s ", "array");
        }
        if(strcmp (argv[i], "ll") == 0){
           run_linear_list = 1;
           //printf("%13s ", "list");
        }
        if(strcmp (argv[i], "ba") == 0){
          run_binary_array = 1;
          //printf("%13s ", "binary");
        }
        if(strcmp (argv[i], "bt") == 0){
          run_binary_tree = 1;
          //printf("%13s ", "tree");
        }
        else{
          //printf("%13s ", "array"); 
          //printf("%13s ", "list"); 
          //printf("%13s ", "binary");
          //printf("%13s ", "tree");
        }
  }
  }
      // 4 different checks to see what argv[i] is
      // based on that, you are going to turn on (set th)

  //will populate the data structure with the sequence 0,2,4,...,(len-1)*2
  //will populate the data structure with the sequence 0,2,4,...,(len-1)*2



clock_t begin, end;           // Variables for timing
double cpu_time = 0;

  printf("%6s ", "LENGTH");
  printf("%10s ", "SEARCHES");
    if(run_linear_array){
      printf("%13s ", "array");      
    }
    if(run_linear_list == 1){
      printf("%13s ", "list");      
    }
    if(run_binary_array == 1){
      printf("%13s ", "binary");      
    }
    if(run_binary_tree == 1){
      printf("%13s ", "tree");     
    }
    printf("\n");

for(int len = min_pow; len<=
max_pow; len++){
  //len* 2 * repetitions
  int current = 1 << len ;
  int max = 2 *current;
  printf("%6d %10d", current, current * repetitions * 2);
if(run_linear_array){
    // run loops to time linear search in an array
    int *array = make_evens_array(current); //will populate the data structure with the sequence 0,2,4,...,(len-1)*2
    begin = clock();

    for(int i=0; i<repetitions; i++){
      for(int j =0; j<max; j++){
        linear_array_search(array, current, j);
      }
    }
    end = clock();
    cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;
    //print output
    printf("    %10.4e", cpu_time);
    //free array
    free(array);
  }
if(run_linear_list){
     // run loops to time linear search in a list
    list_t *list = make_evens_list(current);
    begin = clock();
    for(int i=0; i<repetitions; i++){
      for(int j = 0; j<max; j++){
        linkedlist_search(list, current, j);
      }
    }
    end = clock();
    cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;
    // print out
    printf("    %10.4e", cpu_time);
    // list free
    list_free(list);
  }
if(run_binary_array){
     // run loops to time binary search in an array
    int *array = make_evens_array(current); //will populate the data structure with the sequence 0,2,4,...,(max-1)*2
    begin = clock();
    for(int i=0; i<repetitions; i++){
      for(int j = 0; j<max; j ++){
        binary_array_search(array, current, j);
      }
    }
    end = clock();
    cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;
    //print output
    printf("    %10.4e", cpu_time);
    //free array
    free(array);
  }
if(run_binary_tree){
     // run loops to time binary search in a tree
    bst_t *tree = make_evens_tree(current);
    begin = clock();
    for(int i=0; i<repetitions; i++){
      for(int j =0; j < max; j++){
        binary_tree_search(tree, current, j); //what is int ignore?
      }
    }
    end = clock();
    cpu_time = ((double) (end - begin)) / CLOCKS_PER_SEC;
    //print output
    printf("    %10.4e", cpu_time);
    bst_free(tree);
  }
  printf("\n");
}

 return 0;
}
