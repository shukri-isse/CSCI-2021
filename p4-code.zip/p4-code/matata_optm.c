// optimized versions of matrix A^T*A operation
#include "matvec.h"
#include <memory.h>

// // for (int i=0; i<mat.rows; i++){
// //   for (int j=0; j<mat.cols; j++){
// //     //MSET(ans, i, j, 0);
// //     memset(&ans, 0, sizeof array);
// //   }
// // }
// int matata_VER1(matrix_t mat, matrix_t ans) {
//   memset(ans.data, 0, ans.rows*ans.cols*sizeof(int)); //alternative method using memset that doesn't use nested loop to "zeroed out", it is possible that functions like memset() can perform faster than iteration.
//   int new = 0;
//   int cur = 0; 
//   for(int row=0; row<mat.rows; row++){                // compute ans = A^T * A
//     for(int i=0; i<mat.rows; i++){                          // initial sum 0's
//       int lead = MGET(mat,row,i);                 
//       for(int k=i; k<mat.cols; k++){            // change where this one starts
//         new = lead * MGET(mat, row, k);
//         cur = MGET(ans, i, k);
//         new += cur;
//         MSET(ans, i, k, new);
//       }
//     }
//   }

//   // copy upper right to lower left (Mij = Mji)
//   for(int i = 0; i< mat.rows; i++){
//     for(int j =0; j<i; j++){
//       int new = MGET(ans, j, i);
//       MSET(ans, i, j, new);
//     }
//   }
//   return 0;                                     // return success
// }
// ADDITIONAL VERSIONS HERE
int matata_VER2(matrix_t mat, matrix_t ans) {
  memset(ans.data, 0, ans.rows*ans.cols*sizeof(int)); //alternative method using memset that doesn't use nested loop to "zeroed out", it is possible that functions like memset() can perform faster than iteration.
  int new = 0;
  int new1 = 0;
  int new2 = 0;
  int cur = 0; 
  for(int row=0; row<mat.rows; row++){                // compute ans = A^T * A
    for(int i=0; i<mat.cols; i++){                          // initial sum 0's
      int lead = MGET(mat,row,i);
      int k = i;
      for(; k<mat.cols-3; k+=3){            // change where this one starts
        new = lead * MGET(mat, row, k);
        cur = MGET(ans, i, k);
        new += cur;
        MSET(ans, i, k, new);

        new1 = lead * MGET(mat, row, k+1);
        cur = MGET(ans, i, k+1);
        new1 += cur;
        MSET(ans, i, k+1, new1);

        new2 = lead * MGET(mat, row, k+2);
        cur = MGET(ans, i, k+2);
        new2 += cur;
        MSET(ans, i, k+2, new2);
      }
         for (; k < mat.cols; k++) { //clean up loop which gets the last three loops I might have missed
           new = lead * MGET(mat, row, k);
           cur = MGET(ans, i, k);
           new += cur;
           MSET(ans, i, k, new);
           }
    }
  }
    // copy upper right to lower left (Mij = Mji)
  for(int i = 0; i< mat.rows; i++){
    for(int j =0; j<i; j++){
      int new = MGET(ans, j, i);
      MSET(ans, i, j, new);
    }
  }
  return 0;                                     // return success
}


int matata_OPTM(matrix_t mat, matrix_t ans) {
  if(mat.rows != mat.cols ||                    // must be a square matrix for A^T*A
     mat.rows != ans.rows ||
     mat.cols != ans.cols)
  {
    printf("matata_OPTM: dimension mismatch\n");
    return 1;
  }

  // Call to some version of optimized code
  //return matata_VER1(mat, ans);
  return matata_VER2(mat, ans);
  
}
